CATALOGUE WEB — ÉDITIONS SABAKÉ

Ce dossier contient une maquette de catalogue autonome.

IMPORTANT
- Les fiches et couvertures sont des exemples à remplacer par les vraies informations.
- L’adresse e-mail de commande est fictive et doit être remplacée.
- Ce dossier n’est pas encore publié sur Internet : il ne possède donc pas encore de lien public.

POUR OBTENIR UN LIEN PUBLIC AVEC GITHUB PAGES
1. Connectez-vous à https://github.com/ et créez un compte si nécessaire.
2. Créez un nouveau dépôt public nommé sabake-catalogue.
3. Téléversez le fichier index.html à la racine du dépôt.
4. Ouvrez Settings > Pages.
5. Dans Build and deployment, choisissez Deploy from a branch, puis la branche main et le dossier /(root), puis Save.
6. Après le déploiement, GitHub affichera une adresse publique de type https://VOTRE-NOM.github.io/sabake-catalogue/
7. Dans Google Sites, ouvrez la page Catalogue, choisissez Insérer > Intégrer > Par URL et collez cette adresse.

L’URL finale dépend du nom de votre compte GitHub et ne peut pas être devinée à l’avance.
